

import javax.jms.*;
import org.apache.activemq.ActiveMQConnectionFactory;

public class BillingSystem {

	private final static int firstPrime = 37237573;
	private final static int secondPrime = 50511;
	private final static int someNumberE = 65537;
	private final static int failPercent = 5;
	
	private final static int firstPrime2 = 5077;
	private final static int secondPrime2 = 241;
	private final static int someNumberE2 = 11;
	private static int hashInp; 
	

	
	public static void main(String[] args) {
		try {
            // Parse the string argument into an integer value.
			

		    ActiveMQConnectionFactory conFactory = new ActiveMQConnectionFactory();
	        conFactory.setTrustAllPackages(true);
	        Connection connection = conFactory.createConnection();
	        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
	       
	        Topic topic = session.createTopic("ORDER");
	        MessageConsumer messageConsumer = session.createConsumer(topic);
	        
	        Queue outQueue = session.createQueue("BILL_INV_ORDER");
	        MessageProducer messageProducer = session.createProducer(outQueue);
	        
	        messageConsumer.setMessageListener(new MessageListener() {
	            @Override
	            public void onMessage(Message message) {
	            	try {
						Order order = (Order) ((ObjectMessage) message).getObject();
						hashInp = Integer.parseInt(order.getCustomerID());
						Boolean validity = hash(hashInp);
						order.setValid(validity.toString());
						System.out.println("order validitiy: "+order.getValid());
						
						 ObjectMessage msg = session.createObjectMessage(order);
						 msg.setJMSCorrelationID(order.getOrderID());
				         messageProducer.send(msg);
					} catch (JMSException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	           
	            } 
	        });
	        
	        connection.start();
			} catch (JMSException | NumberFormatException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	}

	
	
	
	
	/**
	 * hash bildet mithilfe der AES-Methode jede Zahl in der Eingabe auf true oder false
	 * Jede Zahl hat eine wahrscheinlichkeit von failPercent false zu sein.
	 * Das heißt für unsere Anwendung, dass failPercent unserer Klientels als unzuverlässig bewertet wird.
	 * 
	 * @param inputInt
	 * @return
	 */
	
	public static boolean hash(int inputInt) {
		final String secretKey = "Yo hommie Trump is gonna win, build a wall around memes and make the 4channers pay for it.";
		String originalString = Integer.toString(inputInt);
	    String encryptedString = AES.encrypt(originalString, secretKey) ;

	    int k = 0;
	    
	    for(int j = 0 ; j<20 ; j++) {
	    	k += ((int) encryptedString.toString().charAt(j)) * (10^j);
	    }
	    
		return (k % 100  > failPercent) ? true : false;
	}
	
	

	public static void test() {

		final String secretKey = "Yo hommie Trump is gonna win, build a wall around memes and make the 4channers pay for it.";
	     
		int pos = 0;
		int neg = 0;
		
		for(int i = 0; i <= 100000 ; i++) {
			
			String originalString = Integer.toString(i);
		    String encryptedString = AES.encrypt(originalString, secretKey) ;
			
		    int k = 0;
		    
		    for(int j = 0 ; j<20 ; j++) {
		    	k += ((int) encryptedString.toString().charAt(j)) * (10^j);
		    }
		    if(k % 100 < failPercent) {
		    	System.out.print("0");
		    	pos++;
		    }else {
		    	System.out.print("1");
		    	neg++;
		    }
		    
			
		}
		System.out.println();
	    System.out.println(pos);
	    System.out.println(neg);

	}

	
}
